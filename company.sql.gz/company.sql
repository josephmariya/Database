-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2020 at 08:11 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `empid` int(10) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `salary` int(8) NOT NULL,
  `joining_date` date NOT NULL,
  `department` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`empid`, `first_name`, `last_name`, `salary`, `joining_date`, `department`) VALUES
(1, 'mariya', 'joseph', 30000, '2020-05-01', 'it'),
(2, 'sajini', 'john', 60000, '2019-08-15', 'hr'),
(3, 'siril', 'joseph', 80000, '2020-09-01', 'mechanical'),
(4, 'charles', 'chacko', 15000, '2020-04-02', 'it'),
(5, 'joseph', 'kk', 30000, '2019-07-03', 'it'),
(6, 'dayana', 'chacko', 40000, '2019-11-06', 'developer'),
(7, 'janson ', 'george', 50000, '2019-08-05', 'manager'),
(8, 'lifny', 'jolly', 75000, '2020-02-03', 'production'),
(9, 'steevan', 'ev', 25000, '2020-01-08', 'marketting'),
(9, 'ancy', 'joseph', 20000, '2020-01-17', 'tecnical'),
(11, 'jismy', 'jose', 35000, '2019-12-17', 'administration'),
(12, 'kukkumol', 'thomas', 35000, '2020-01-30', 'developer'),
(13, 'nimmya', 'ts', 40000, '2020-03-02', 'marketting'),
(14, 'aswathy', 'mk', 25000, '2020-07-10', 'administrator'),
(15, 'anoop', 'joy', 60000, '2020-01-15', 'research');

-- --------------------------------------------------------

--
-- Table structure for table `incentives`
--

CREATE TABLE `incentives` (
  `empid` int(10) NOT NULL,
  `incentive_date` date NOT NULL,
  `incentive_amount` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incentives`
--

INSERT INTO `incentives` (`empid`, `incentive_date`, `incentive_amount`) VALUES
(3, '2020-01-15', 10000),
(9, '2020-01-06', 15000),
(12, '2019-07-01', 10000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
